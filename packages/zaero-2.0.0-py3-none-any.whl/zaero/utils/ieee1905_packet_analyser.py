# Copyright 2026 Zilogic Systems
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import pyshark
from collections import defaultdict

from zaero.bridge.database_module import DatabaseModule
import zaero.utils.zi_logger as zi_logger

class Ieee1905PacketAnalyser(DatabaseModule):    
    """
    A library to validate the EasyMesh agent onboarding sequence from the
    IEEE1905.1 CMDUs in a capture file. Message types, onboarding steps and
    timing limits are read from the ieee1905 config.
    """

    ROBOT_AUTO_KEYWORDS = False
    ROBOT_LIBRARY_SCOPE = 'Global'

    def __init__(self):
        zi_logger.print_context()
        DatabaseModule.__init__(self)
        self.db_obj = self.get_database_module_object()

    def __get_msg_type(self,
                       ieee1905_layer):
        """
        Get the CMDU message type from an IEEE1905 packet layer.

        ``ieee1905_layer`` is the pyshark ieee1905 layer of a packet

        ``returns`` the message type as an integer, or None if not found
        """
        zi_logger.print_context()
        ieee1905_message_type_fields = self.db_obj.read_from_database("ieee1905_message_type_fields")
        for field in ieee1905_message_type_fields:
            if hasattr(ieee1905_layer, field):
                field_value = getattr(ieee1905_layer, field)
                try:
                    return int(field_value, 16) if str(field_value).lower().startswith("0x") else int(field_value)
                except ValueError:
                    continue
        return None

    def __filter_ieee1905_packets(self,
                                  pcap_file: str):
        """
        Read the IEEE1905.1 CMDUs from a capture file.

        ``pcap_file`` is the local path of the capture file

        ``returns`` the list of CMDU events (frame number, timestamp, message
        type and name, source and destination MAC) sorted by time
        """
        zi_logger.print_context()
        cap = pyshark.FileCapture(pcap_file, display_filter="ieee1905", use_json=True, include_raw=False)
        events = []
        ieee1905_message_types = self.db_obj.read_from_database("ieee1905_message_types")
        i = 1
        i_skip = 1
        mt_skip = 1
        for pkt in cap:
            i += 1
            try:
                ieee1905_layer = pkt.ieee1905
            except AttributeError:
                i_skip += 1
                continue

            msg_type = self.__get_msg_type(ieee1905_layer)
            if msg_type is None:
                mt_skip += 1
                continue

            src = getattr(pkt.eth, "src", None) if hasattr(pkt, "eth") else None
            dst = getattr(pkt.eth, "dst", None) if hasattr(pkt, "eth") else None

            events.append({
                "frame_no": int(pkt.number),
                "timestamp": float(pkt.sniff_timestamp),
                "message_type": msg_type,
                "message_name": ieee1905_message_types.get(msg_type, f"Unknown (0x{msg_type:04X})"),
                "src": src,
                "dst": dst,
            })

        cap.close()
        events.sort(key=lambda e: e["timestamp"])
        return events

    def __validate_onboarding_sequence(self,
                                       events):
        """
        Check that each configured onboarding step appears in the events.

        ``events`` is the list of CMDU events

        ``returns`` one result per step with its status - PASS, FAIL, or
        SKIP for an optional step that was not seen
        """
        zi_logger.print_context()
        by_type = defaultdict(list)
        for e in events:
            by_type[e["message_type"]].append(e)

        results = []
        onbording_steps = self.db_obj.read_from_database("ieee1905_onboarding_steps")
        for step in onbording_steps:
            name = step['name']
            code = step['message_type']
            required = step['required']
            occurrences = by_type.get(code, [])
            if occurrences:
                status = "PASS"
            elif required:
                status = "FAIL"
            else:
                status = "SKIP (optional, not seen)"
            results.append({
                "step": name,
                "code": f"0x{code:04X}",
                "required": required,
                "count": len(occurrences),
                "status": status,
                "first_seen": occurrences[0]["timestamp"] if occurrences else None,
            })
        return results

    def __validate_onboarding_timing(self,
                                     events):
        """
        Check the timing of the AP-Autoconfiguration Search/Response and the
        WSC M1/M2 exchange against the configured limits.

        ``events`` is the list of CMDU events

        ``returns`` the list of timing issues found, empty if none
        """
        zi_logger.print_context()
        issues = []
        by_type = defaultdict(list)
        for e in events:
            by_type[e["message_type"]].append(e)

        search = by_type.get(0x0007, [])
        response = by_type.get(0x0008, [])
        ieee1905_max_gap_secs = self.db_obj.read_from_database("ieee1905_max_gap_secs")
        if search and response:
            gap = response[0]["timestamp"] - search[0]["timestamp"]
            limit = ieee1905_max_gap_secs["search_to_response"]
            if gap < 0:
                issues.append("AP-Autoconfiguration Response seen before Search "
                              "(check for a second/unrelated agent in this capture)")
            elif gap > limit:
                issues.append(f"AP-Autoconfiguration Search -> Response gap too long: "
                              f"{gap:.2f}s (expected < {limit}s)")
        elif search and not response:
            issues.append("AP-Autoconfiguration Search seen with no Response \u2014 "
                          "Controller may not have replied")

        wsc = by_type.get(0x0009, [])
        if len(wsc) >= 2:
            gap = wsc[1]["timestamp"] - wsc[0]["timestamp"]
            limit = ieee1905_max_gap_secs["wsc_m1_to_m2"]
            if gap > limit:
                issues.append(f"AP-Autoconfiguration WSC M1 -> M2 gap too long: "
                              f"{gap:.2f}s (expected < {limit}s)")
        elif len(wsc) == 1:
            issues.append("Only one AP-Autoconfiguration WSC CMDU seen "
                          "(expected an M1/M2 pair \u2014 onboarding likely incomplete)")
        else:
            issues.append("No AP-Autoconfiguration WSC (WPS M1/M2) CMDUs seen at all")
            
        return issues

    def __group_macs(self,
                     events):
        """
        Collect the device MAC addresses seen in the events, leaving out the
        IEEE1905 multicast address.

        ``events`` is the list of CMDU events

        ``returns`` the set of MAC addresses
        """
        zi_logger.print_context()
        macs = set()
        for e in events:
            if e["src"]:
                macs.add(e["src"])
            if e["dst"] and e["dst"].lower() != "01:80:c2:00:00:13":
                macs.add(e["dst"])
        return macs

    def __validate_report(self,
                          events,
                          seq_results,
                          timing_issues):
        """
        Print the onboarding validation report: summary, sequence checklist,
        timing issues and the CMDU timeline.

        ``events`` is the list of CMDU events
        and ``seq_results`` is the result of the sequence validation
        and ``timing_issues`` is the result of the timing validation

        ``returns`` True if all required steps passed with no timing issues
        """
        zi_logger.print_context()
        print("=" * 78)
        print("prplMesh / EasyMesh Agent Onboarding Validation Report")
        print("=" * 78)

        print(f"\nTotal 1905.1 CMDUs captured: {len(events)}")
        if events:
            duration = events[-1]["timestamp"] - events[0]["timestamp"]
            print(f"Capture window: {duration:.2f} seconds")

        macs = self.__group_macs(events)
        print(f"Distinct device MACs seen: {', '.join(sorted(macs)) if macs else 'none'}")

        print("\n--- Onboarding Sequence Checklist ---")
        print(f"{'Step':<38}{'Code':<9}{'Status':<28}{'Count'}")
        print("-" * 85)
        all_required_passed = True
        for r in seq_results:
            print(f"{r['step']:<38}{r['code']:<9}{r['status']:<28}{r['count']}")
            if r["required"] and r["status"] == "FAIL":
                all_required_passed = False

        print("\n--- Timing Validation ---")
        if timing_issues:
            for issue in timing_issues:
                print(f"  [!] {issue}")
        else:
            print("  No timing issues detected.")

        print("\n--- Chronological CMDU Timeline ---")
        print(f"{'Frame':<8}{'Rel Time(s)':<13}{'Message':<38}{'Src':<19}{'Dst'}")
        print("-" * 100)
        t0 = events[0]["timestamp"] if events else 0
        for e in events:
            rel = e["timestamp"] - t0
            print(f"{e['frame_no']:<8}{rel:<13.3f}{e['message_name']:<38}"
                  f"{(e['src'] or ''):<19}{e['dst'] or ''}")

        print("\n" + "=" * 78)
        if all_required_passed and not timing_issues:
            print("RESULT: PASS - onboarding sequence is complete and well-formed")
        elif all_required_passed:
            print("RESULT: PASS WITH WARNINGS - required messages present, "
                  "but timing issues were found")
        else:
            print("RESULT: FAIL - one or more required onboarding messages are missing")
        print("=" * 78)
        return all_required_passed and not timing_issues

    def validate_ieee1905_onboarding(self,
                                     pcap_file: str):
        """
        Validate the EasyMesh agent onboarding sequence in a capture file and
        print a validation report.

        ``pcap_file`` is the local path of the capture file

        ``raise`` RuntimeError if no IEEE1905.1 CMDUs are found, a required
        onboarding message is missing or a timing issue is found
        """
        zi_logger.print_context()
        events = self.__filter_ieee1905_packets(pcap_file)
        if not events:
            raise RuntimeError("No IEEE1905.1 CMDUs were found in the capture.")
        seq_results = self.__validate_onboarding_sequence(events)
        timing_issues = self.__validate_onboarding_timing(events)
        result = self.__validate_report(events, seq_results, timing_issues)

        if not result:
            raise RuntimeError("IEEE1905 protocol validation for onboarding FAILED.")
