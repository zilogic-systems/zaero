# Copyright 2026 Zilogic Systems
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""
This module handles operating system abstract methods

Author: Zilogic Systems <code@zilogic.com>
"""
from abc import ABC, abstractmethod


class BaseFeatureOperatingSystem(ABC):
    """ This module provides abstract class for the APIs in operating system"""

    @abstractmethod
    def get_openwrt_version(self, device: str):
        """ Get OpenWrt version abstract method"""
        raise NotImplementedError("Subclass must implement get_openwrt_version()")

    @abstractmethod
    def get_os_release(self, device: str):
        """ Get OS release abstract method"""
        raise NotImplementedError("Subclass must implement get_os_release()")

    @abstractmethod
    def get_kernel_version(self, device: str):
        """ Get kernel version abstract method"""
        raise NotImplementedError("Subclass must implement get_kernel_version()")
