# Copyright 2025 Zilogic Systems
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""
Author: Zilogic Systems <code@zilogic.com>
"""


from robot.api.deco import keyword

from zaero.bridge.database_module import DatabaseModule
from zaero.bridge.utils_modules import UtilsModules
import zaero.utils.zi_logger as zi_logger

class Ieee1905PacketAnalyser(DatabaseModule,
                             UtilsModules):
    """
    Ieee1905PacketAnalyser is a python library designed for ieee1905 protcol analysis automation.
    """

    ROBOT_AUTO_KEYWORDS = False
    ROBOT_LIBRARY_SCOPE = 'Global'

    def __init__(self):
        zi_logger.print_context()
        DatabaseModule.__init__(self)
        UtilsModules.__init__(self)
        self.db_obj = self.get_database_module_object()
        zi_logger.log(f"==== db_obj : {self.db_obj}")
        zi_logger.log("PacketSniffer __init__ : END")

    @keyword("Validate ieee1905 onboarding")
    def validate_ieee1905_onboarding(self,
                                     pcap_file: str):
        """
        Validate the EasyMesh agent onboarding sequence in a capture file and
        print a validation report.

        - ``pcap_file`` is the local path of the capture file to analyse

        ``raise`` RuntimeError if no IEEE1905.1 CMDUs are found, a required
        onboarding message is missing or a timing issue is found

        Example:
        | Validate ieee1905 onboarding | /home/user/pcap_logs/onboarding.pcap |
        """
        zi_logger.print_context()
        utils_obj = self.get_utils_module_object('ieee1905_packet_analyser')
        utils_obj.validate_ieee1905_onboarding(pcap_file)
